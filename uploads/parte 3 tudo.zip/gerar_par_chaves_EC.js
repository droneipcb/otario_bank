// exemplo de criação de par de chaves de curva eliptica

const crypto = require ("crypto");
const fs = require('fs');

// neste exemplo, vamos usar a curva secpt521r1
const curv = crypto.createECDH('secp521r1');
curv.generateKeys();

const publicKey=curv.getPublicKey();
const privateKey=curv.getPrivateKey();

// mostra a chave publica
console.log("\r\nPublic Key: ", publicKey.toString('hex'));

fs.writeFileSync('chave_publica_EC_professor.bin', publicKey);


// mostra a chave privada
console.log("\r\nPrivate Key :", privateKey.toString('hex'));

fs.writeFileSync('chave_privada_EC_professor.bin', privateKey);

